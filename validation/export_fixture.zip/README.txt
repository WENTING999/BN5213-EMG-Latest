BN5213 recording. Inspect metadata.json first. SIMULATION, firmware_simulation and mouse rows are not physiological observations.
EMG is a rectified/smoothed sensor envelope in ADC counts, not skin microvolts or force.
Serial alignment is estimated using ping round trips; physical monitor/camera/analogue delays were not measured.
Observer confirmation times are manual markers and do not validate actual standing duration or leg balance.
