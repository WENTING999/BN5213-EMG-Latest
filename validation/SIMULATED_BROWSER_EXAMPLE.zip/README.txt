Read metadata.json before analysis. All *_perf_ms use this page performance.now() clock; session_ms is relative to recording start. Device clock alignment is estimated, not physically validated.
SIMULATION/firmware_simulation/mouse_simulation are not human measurements. Blank pupil.csv means no pupil data, not zero diameter. Do not mix mm and pixels.
EMG is the board envelope in ADC counts, not raw skin microvolts, force or pressure. Observer markers do not validate standing duration or bilateral balance.
Exclude trials with validForTiming=false from reaction-time analysis. Aborted and fast-demo sessions must be filtered explicitly. Separate conditions, gaze sources and EMG sources.
